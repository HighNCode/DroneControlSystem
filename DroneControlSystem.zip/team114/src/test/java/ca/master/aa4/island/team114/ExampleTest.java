package ca.mcmaster.seaa4.island.team114;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class ExampleTest {

    @Test
    public void sampleTest() {
        assertTrue(1 == 1);
    }


}
